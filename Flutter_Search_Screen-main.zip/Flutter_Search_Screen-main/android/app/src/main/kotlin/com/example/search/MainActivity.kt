package com.example.search

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
